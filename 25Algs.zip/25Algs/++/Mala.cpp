#include "Mala.h"

Mala::Mala() {
}

Mala::~Mala() {
}

int Mala::move() {
	return 0;
}

void Mala::update(int *acts) {
}
